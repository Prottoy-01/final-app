package com.example.my_final_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Home extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button listViewButton = findViewById(R.id.listViewButton);
        Button recyclerViewButton = findViewById(R.id.recyclerViewButton);

        listViewButton.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, ListViewActivity.class);
            startActivity(intent);
        });

        recyclerViewButton.setOnClickListener(v -> {
            Intent intent = new Intent(Home.this, RecyclerViewActivity.class);
            startActivity(intent);
        });
    }
}
